﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblsmall = New System.Windows.Forms.Label()
        Me.lblmed = New System.Windows.Forms.Label()
        Me.lbllrg = New System.Windows.Forms.Label()
        Me.lblpricesm = New System.Windows.Forms.Label()
        Me.lblpricemed = New System.Windows.Forms.Label()
        Me.lblpricelrg = New System.Windows.Forms.Label()
        Me.lstoutput = New System.Windows.Forms.ListBox()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.lblqsm = New System.Windows.Forms.Label()
        Me.lblqmed = New System.Windows.Forms.Label()
        Me.lblqlrg = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblsmall
        '
        Me.lblsmall.AutoSize = True
        Me.lblsmall.Location = New System.Drawing.Point(126, 52)
        Me.lblsmall.Name = "lblsmall"
        Me.lblsmall.Size = New System.Drawing.Size(24, 13)
        Me.lblsmall.TabIndex = 0
        Me.lblsmall.Text = "4x6"
        '
        'lblmed
        '
        Me.lblmed.AutoSize = True
        Me.lblmed.Location = New System.Drawing.Point(126, 91)
        Me.lblmed.Name = "lblmed"
        Me.lblmed.Size = New System.Drawing.Size(30, 13)
        Me.lblmed.TabIndex = 1
        Me.lblmed.Text = "8x10"
        '
        'lbllrg
        '
        Me.lbllrg.AutoSize = True
        Me.lbllrg.Location = New System.Drawing.Point(126, 131)
        Me.lbllrg.Name = "lbllrg"
        Me.lbllrg.Size = New System.Drawing.Size(36, 13)
        Me.lbllrg.TabIndex = 2
        Me.lbllrg.Text = "16x20"
        '
        'lblpricesm
        '
        Me.lblpricesm.AutoSize = True
        Me.lblpricesm.Location = New System.Drawing.Point(203, 52)
        Me.lblpricesm.Name = "lblpricesm"
        Me.lblpricesm.Size = New System.Drawing.Size(28, 13)
        Me.lblpricesm.TabIndex = 3
        Me.lblpricesm.Text = "1.99"
        '
        'lblpricemed
        '
        Me.lblpricemed.AutoSize = True
        Me.lblpricemed.Location = New System.Drawing.Point(203, 91)
        Me.lblpricemed.Name = "lblpricemed"
        Me.lblpricemed.Size = New System.Drawing.Size(28, 13)
        Me.lblpricemed.TabIndex = 4
        Me.lblpricemed.Text = "4.99"
        '
        'lblpricelrg
        '
        Me.lblpricelrg.AutoSize = True
        Me.lblpricelrg.Location = New System.Drawing.Point(203, 131)
        Me.lblpricelrg.Name = "lblpricelrg"
        Me.lblpricelrg.Size = New System.Drawing.Size(28, 13)
        Me.lblpricelrg.TabIndex = 5
        Me.lblpricelrg.Text = "7.99"
        '
        'lstoutput
        '
        Me.lstoutput.FormattingEnabled = True
        Me.lstoutput.Location = New System.Drawing.Point(335, 49)
        Me.lstoutput.Name = "lstoutput"
        Me.lstoutput.Size = New System.Drawing.Size(120, 95)
        Me.lstoutput.TabIndex = 6
        '
        'btncalc
        '
        Me.btncalc.Location = New System.Drawing.Point(153, 201)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(75, 23)
        Me.btncalc.TabIndex = 7
        Me.btncalc.Text = "Calculate"
        Me.btncalc.UseMnemonic = False
        Me.btncalc.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(243, 201)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(75, 23)
        Me.btnclear.TabIndex = 8
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(335, 201)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(75, 23)
        Me.btnexit.TabIndex = 9
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'lblqsm
        '
        Me.lblqsm.AutoSize = True
        Me.lblqsm.Location = New System.Drawing.Point(258, 52)
        Me.lblqsm.Name = "lblqsm"
        Me.lblqsm.Size = New System.Drawing.Size(13, 13)
        Me.lblqsm.TabIndex = 10
        Me.lblqsm.Text = "0"
        '
        'lblqmed
        '
        Me.lblqmed.AutoSize = True
        Me.lblqmed.Location = New System.Drawing.Point(258, 91)
        Me.lblqmed.Name = "lblqmed"
        Me.lblqmed.Size = New System.Drawing.Size(13, 13)
        Me.lblqmed.TabIndex = 11
        Me.lblqmed.Text = "0"
        '
        'lblqlrg
        '
        Me.lblqlrg.AutoSize = True
        Me.lblqlrg.Location = New System.Drawing.Point(258, 131)
        Me.lblqlrg.Name = "lblqlrg"
        Me.lblqlrg.Size = New System.Drawing.Size(13, 13)
        Me.lblqlrg.TabIndex = 12
        Me.lblqlrg.Text = "0"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(632, 398)
        Me.Controls.Add(Me.lblqlrg)
        Me.Controls.Add(Me.lblqmed)
        Me.Controls.Add(Me.lblqsm)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.btncalc)
        Me.Controls.Add(Me.lstoutput)
        Me.Controls.Add(Me.lblpricelrg)
        Me.Controls.Add(Me.lblpricemed)
        Me.Controls.Add(Me.lblpricesm)
        Me.Controls.Add(Me.lbllrg)
        Me.Controls.Add(Me.lblmed)
        Me.Controls.Add(Me.lblsmall)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblsmall As Label
    Friend WithEvents lblmed As Label
    Friend WithEvents lbllrg As Label
    Friend WithEvents lblpricesm As Label
    Friend WithEvents lblpricemed As Label
    Friend WithEvents lblpricelrg As Label
    Friend WithEvents lstoutput As ListBox
    Friend WithEvents btncalc As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents lblqsm As Label
    Friend WithEvents lblqmed As Label
    Friend WithEvents lblqlrg As Label
End Class
