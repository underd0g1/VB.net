﻿Public Class Form1
    Const tax = 0.06
    Const small = 1.99
    Const med = 4.99
    Const lrg = 7.99
    Dim quantitysm As Double
    Dim quantitymd As Double
    Dim quantitylg As Double
    Dim totsm As Double
    Dim totmed As Double
    Dim totlrg As Double



    Private Sub lblsmall_Click(sender As Object, e As EventArgs) Handles lblsmall.Click


        quantitysm = InputBox("how many do you want to order?")
        lblpricesm.Text = FormatCurrency(quantitysm * small, 2)
        lblqsm.Text = quantitysm
        totsm = quantitysm * small

    End Sub

    Private Sub lblmed_Click(sender As Object, e As EventArgs) Handles lblmed.Click

        quantitymd = InputBox("How many do you want to order?")
        lblpricemed.Text = FormatCurrency(quantitymd * med, 2)
        lblqmed.Text = quantitymd
        totmed = quantitysm * med
    End Sub

    Private Sub lbllrg_Click(sender As Object, e As EventArgs) Handles lbllrg.Click

        quantitylg = InputBox("How Many Do you Want to order")
        lblpricelrg.Text = FormatCurrency(quantitylg * lrg, 2)
        lblqlrg.Text = quantitylg
        totlrg = quantitylg * lrg
    End Sub

    Private Sub btncalc_Click(sender As Object, e As EventArgs) Handles btncalc.Click
        Dim subtotal, total, tax As Double
        subtotal = totsm + totmed + totlrg
        tax = 0.06 * subtotal
        total = subtotal + tax
        lstoutput.Items.Add("Sm: " & FormatCurrency(totsm, 2))
        lstoutput.Items.Add("Med: " & FormatCurrency(totmed, 2))
        lstoutput.Items.Add("Lrg: " & FormatCurrency(totlrg, 2))
        lstoutput.Items.Add("Subtotal: " & FormatCurrency(subtotal, 2))
        lstoutput.Items.Add("Tax: " & FormatCurrency(tax, 2))
        lstoutput.Items.Add("Total: " & FormatCurrency(total, 2))
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        lblpricelrg.Text = "7.99"
        lblpricemed.Text = "4.99"
        lblpricesm.Text = "1.99"
        lblqsm.Text = "0"
        lblqmed.Text = "0"
        lblqlrg.Text = "0"
        lstoutput.Items.Clear()

    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        End
    End Sub
End Class
