﻿'todo 10/23/18
' change the checked changed names for the toppings 
' add += for the toppings

'apply the discount if they order three or more toppings

'todo 10/29/18
'allow for all the items to be cleared
'allow the choices to be changed during runtime
'clean up the formatting



Public Class Form1
    'declare constant variables

    Dim dbltoppingprice As Double
    Dim strtoppings As String
    Dim strsodatype As String
    Dim dblsodaprice As Double
    Dim dblbreadstickprice As Double
    Dim dblpizzaprice As Double
    Dim delivery As Double = 3.5
    Const tax = 0.06
    Dim dblsubtotal As Double
    Dim dbltotal As Double
    Dim dbl3discount As Double
    Dim dbltax As Double
    Dim strname As String
    Dim sizeflagsm As Boolean
    Dim sizeflagmd As Boolean
    Dim sizeflaglg As Boolean

    Dim dbltop As Double





    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'add the number of breadsticks options
        cbobread.Items.Add(0)
        cbobread.Items.Add(1)
        cbobread.Items.Add(2)
        cbobread.Items.Add(3)
        cbobread.Items.Add(4)
        cbobread.Items.Add(5)

        ' add the number of pizzas options
        cbonum.Items.Add(0)
        cbonum.Items.Add(1)
        cbonum.Items.Add(2)
        cbonum.Items.Add(3)
        cbonum.Items.Add(4)
        cbonum.Items.Add(5)
    End Sub



    Private Sub radSmall_CheckedChanged(sender As Object, e As EventArgs) Handles radSmall.CheckedChanged
        dblpizzaprice = cbonum.Text * 7
        dbltop = 1
        sizeflagsm = True
    End Sub

    Private Sub radMed_CheckedChanged(sender As Object, e As EventArgs) Handles radMed.CheckedChanged
        dblpizzaprice = cbonum.Text * 10
        dbltop = 1.5
        sizeflagmd = True
    End Sub

    Private Sub radLarge_CheckedChanged(sender As Object, e As EventArgs) Handles radLarge.CheckedChanged
        dblpizzaprice = cbonum.Text * 13
        dbltop = 2
        sizeflaglg = True
    End Sub

    Private Sub chkcheese_CheckedChanged(sender As Object, e As EventArgs) Handles chkcheese.CheckedChanged
        If chkcheese.Checked = True Then
            dbltoppingprice += dbltop
        Else
            dbltoppingprice -= dbltop
        End If

    End Sub

    Private Sub chkpep_CheckedChanged(sender As Object, e As EventArgs) Handles chkpep.CheckedChanged
        If chkpep.Checked = True Then
            dbltoppingprice += dbltop

        Else
            dbltoppingprice -= dbltop

        End If
    End Sub

    Private Sub chkveg_CheckedChanged(sender As Object, e As EventArgs) Handles chkveg.CheckedChanged
        If (chkveg.Checked = True) 
            dbltoppingprice += dbltop
        Else
            dbltoppingprice -= dbltop
        End If
    End Sub

    Private Sub chksausage_CheckedChanged(sender As Object, e As EventArgs) Handles chksausage.CheckedChanged
        If (chksausage.Checked = True) Then
            dbltoppingprice += dbltop
        Else
            dbltoppingprice -= dbltop
        End If
    End Sub

    Private Sub chkpine_CheckedChanged(sender As Object, e As EventArgs) Handles chkpine.CheckedChanged
        If (chkpine.Checked = True) Then
            dbltoppingprice += dbltop
        Else
            dbltoppingprice -= dbltop
        End If
    End Sub

    Private Sub chkCoke_CheckedChanged(sender As Object, e As EventArgs) Handles chkCoke.CheckedChanged
        If chkCoke.Checked = True Then
            dblsodaprice = 3.5

        Else
            dblsodaprice -= 3.5
        End If

    End Sub

    Private Sub chksprite_CheckedChanged(sender As Object, e As EventArgs) Handles chksprite.CheckedChanged

        If chksprite.Checked = True Then
            dblsodaprice += 3.5

        Else
            dblsodaprice -= 3.5
        End If
    End Sub

    Private Sub chkBirch_CheckedChanged(sender As Object, e As EventArgs) Handles chkBirch.CheckedChanged

        If chkBirch.Checked = True Then

            dblsodaprice += 3.5
        Else
            dblsodaprice -= 3.5
        End If

    End Sub

    Private Sub radYes_CheckedChanged(sender As Object, e As EventArgs) Handles radYes.CheckedChanged
        delivery = 3.0
    End Sub

    Private Sub radNo_CheckedChanged(sender As Object, e As EventArgs) Handles radNo.CheckedChanged
        delivery = 0
    End Sub

    Private Sub btnComp_Click(sender As Object, e As EventArgs) Handles btnComp.Click

        strname = txtname.Text
        dbltoppingprice *= cbonum.Text
        lstOutput.Items.Add("Your name: " & strname)
        lstOutput.Items.Add("Number of pizzas: " & cbonum.Text & "|   Base Pizza Price  " & dblpizzaprice)
        lstOutput.Items.Add("Toppings: " & FormatCurrency(dbltoppingprice, 2))
        lstOutput.Items.Add("breadsticks: " & cbobread.Text & "|   price: " & FormatCurrency(dblbreadstickprice, 2))
        lstOutput.Items.Add("delivery fee: " & FormatCurrency(delivery, 2))
        lstOutput.Items.Add("soda type: " & strsodatype & " | price: " & FormatCurrency(dblsodaprice, 2))


        Dim dbltoppingdiscount As Double
        dbltoppingdiscount = topdiscount(sizeflagsm, sizeflagmd, sizeflaglg, dbltoppingprice)
        'calculate the subtotal ( pizza price + price of toppings + price of breadsticks + delivery fee + price of the soda)
        dblsubtotal = dblpizzaprice + dbltoppingdiscount + dblbreadstickprice + delivery + dblsodaprice

        'calculate the discount (if all the requirements have values, then that means that they are selected, in turn making them eligible for the discount) 
        ' I assume that the user cannot get the discount more than one time, so the followign if statement is going to apply one discount
        If (dblsubtotal * discount(dblsodaprice, dblbreadstickprice, dblpizzaprice)) > 0 Then

            dbl3discount = dblsubtotal * discount(dblsodaprice, dblbreadstickprice, dblpizzaprice)

        ElseIf (dblsubtotal * namestats(strname)) > 0 Then

            dbl3discount = dblsubtotal * namestats(strname)

        Else

            dbl3discount = 0

        End If

        'calculate the total (the subtotal minus the discount)


        dbltax = tax * (dblsubtotal - dbl3discount)
        dbltotal = FormatCurrency((dblsubtotal - dbl3discount) + dbltax, 2)
        lstOutput.Items.Add("subtotal: " & FormatCurrency(dblsubtotal, 2))
        lstOutput.Items.Add("pizza discount: " & FormatCurrency(dbl3discount, 2))
        lstOutput.Items.Add("toppings price with discount: " & FormatCurrency(dbltoppingdiscount, 2))
        lstOutput.Items.Add("tax: " & FormatCurrency(dbltax, 2))
        lstOutput.Items.Add("total: " & FormatCurrency(dbltotal, 2))
        'display the labels
        lblsubtot.Text = FormatCurrency(dblsubtotal, 2)
        lblTot.Text = FormatCurrency(dbltotal, 2)

    End Sub

    Private Sub cbobread_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbobread.SelectedIndexChanged
        dblbreadstickprice = cbobread.Text * 3.0
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        End
    End Sub

    Private Sub BtnClr_Click(sender As Object, e As EventArgs) Handles BtnClr.Click
        lstOutput.Items.Clear()
        txtname.Text = " "
        radLarge.Checked = False
        radMed.Checked = False
        radSmall.Checked = False
        chkcheese.Checked = False
        chkpep.Checked = False
        chkpine.Checked = False
        chksausage.Checked = False
        chkveg.Checked = False
        radYes.Checked = False
        radNo.Checked = False
        chkCoke.Checked = False
        chksprite.Checked = False
        chkBirch.Checked = False
        cbobread.Text = 0
        cbonum.Text = 0

        lblsubtot.Text = ""
        lblTot.Text = ""


    End Sub

    Private Function discount(sodaprice As Double, breadprice As Double, pizzaprice As Double) As Double
        'change to a boolean conditional
        If (sodaprice > 0) And (breadprice > 0) And (pizzaprice > 0) Then

            discount = 0.1
            MessageBox.Show("you ordered all three foods!")
        Else
            discount = 0
        End If

        Return discount

    End Function

    Private Function namestats(full As String) As Double
        Dim split As Integer
        Dim last, upper As String
        Dim value As Double

        split = full.IndexOf(" ")
        last = full.Substring(split)
        upper = last.ToUpper
        If upper = " DAO" Then
            value = 0.1
            MessageBox.Show("congratz dr dao!")
        Else
            value = 0

        End If
        Return value
    End Function
    Private Function topdiscount(sizesm As Boolean, sizemd As Boolean, sizelg As Boolean, topping As Double) As Double
        If sizeflagsm = True And dbltoppingprice >= 3 Then
            dbltoppingprice -= 1 * cbonum.Text
            MessageBox.Show("you ordered more than three toppings!")
        ElseIf sizeflagmd = True And dbltoppingprice >= 4.5 Then
            dbltoppingprice -= 1.5 * cbonum.Text
            MessageBox.Show("you ordered more than three toppings!")
        ElseIf sizeflaglg = True And dbltoppingprice >= 6 Then
            dbltoppingprice -= 2 * cbonum.Text
            MessageBox.Show("you ordered more than three toppings!")
        Else
            dbltoppingprice -= 0
        End If
        Return dbltoppingprice
    End Function

End Class
