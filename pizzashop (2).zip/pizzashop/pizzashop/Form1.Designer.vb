﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbobread = New System.Windows.Forms.ComboBox()
        Me.cbonum = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radLarge = New System.Windows.Forms.RadioButton()
        Me.radMed = New System.Windows.Forms.RadioButton()
        Me.radSmall = New System.Windows.Forms.RadioButton()
        Me.BtnClr = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnComp = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chksausage = New System.Windows.Forms.CheckBox()
        Me.chkpine = New System.Windows.Forms.CheckBox()
        Me.chkveg = New System.Windows.Forms.CheckBox()
        Me.chkpep = New System.Windows.Forms.CheckBox()
        Me.chkcheese = New System.Windows.Forms.CheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkCoke = New System.Windows.Forms.CheckBox()
        Me.chksprite = New System.Windows.Forms.CheckBox()
        Me.chkBirch = New System.Windows.Forms.CheckBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.radNo = New System.Windows.Forms.RadioButton()
        Me.radYes = New System.Windows.Forms.RadioButton()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTot = New System.Windows.Forms.Label()
        Me.lblsubtot = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstOutput
        '
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.Location = New System.Drawing.Point(344, 376)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(479, 225)
        Me.lstOutput.TabIndex = 0
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(70, 29)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(29, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Name"
        '
        'cbobread
        '
        Me.cbobread.FormattingEnabled = True
        Me.cbobread.Location = New System.Drawing.Point(261, 31)
        Me.cbobread.Name = "cbobread"
        Me.cbobread.Size = New System.Drawing.Size(121, 21)
        Me.cbobread.TabIndex = 3
        '
        'cbonum
        '
        Me.cbonum.FormattingEnabled = True
        Me.cbonum.Location = New System.Drawing.Point(459, 32)
        Me.cbonum.Name = "cbonum"
        Me.cbonum.Size = New System.Drawing.Size(121, 21)
        Me.cbonum.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radLarge)
        Me.GroupBox1.Controls.Add(Me.radMed)
        Me.GroupBox1.Controls.Add(Me.radSmall)
        Me.GroupBox1.Location = New System.Drawing.Point(51, 89)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(225, 174)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pizza Size"
        '
        'radLarge
        '
        Me.radLarge.AutoSize = True
        Me.radLarge.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.radLarge.Location = New System.Drawing.Point(19, 109)
        Me.radLarge.Name = "radLarge"
        Me.radLarge.Size = New System.Drawing.Size(52, 17)
        Me.radLarge.TabIndex = 2
        Me.radLarge.TabStop = True
        Me.radLarge.Text = "Large"
        Me.radLarge.UseVisualStyleBackColor = True
        '
        'radMed
        '
        Me.radMed.AutoSize = True
        Me.radMed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.radMed.Location = New System.Drawing.Point(19, 73)
        Me.radMed.Name = "radMed"
        Me.radMed.Size = New System.Drawing.Size(62, 17)
        Me.radMed.TabIndex = 3
        Me.radMed.TabStop = True
        Me.radMed.Text = "Medium"
        Me.radMed.UseVisualStyleBackColor = True
        '
        'radSmall
        '
        Me.radSmall.AutoSize = True
        Me.radSmall.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.radSmall.Location = New System.Drawing.Point(19, 35)
        Me.radSmall.Name = "radSmall"
        Me.radSmall.Size = New System.Drawing.Size(50, 17)
        Me.radSmall.TabIndex = 4
        Me.radSmall.TabStop = True
        Me.radSmall.Text = "Small"
        Me.radSmall.UseVisualStyleBackColor = True
        '
        'BtnClr
        '
        Me.BtnClr.Location = New System.Drawing.Point(409, 623)
        Me.BtnClr.Name = "BtnClr"
        Me.BtnClr.Size = New System.Drawing.Size(75, 23)
        Me.BtnClr.TabIndex = 6
        Me.BtnClr.Text = "Clear"
        Me.BtnClr.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(525, 623)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnComp
        '
        Me.btnComp.Location = New System.Drawing.Point(639, 623)
        Me.btnComp.Name = "btnComp"
        Me.btnComp.Size = New System.Drawing.Size(75, 23)
        Me.btnComp.TabIndex = 8
        Me.btnComp.Text = "Compute"
        Me.btnComp.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chksausage)
        Me.GroupBox2.Controls.Add(Me.chkpine)
        Me.GroupBox2.Controls.Add(Me.chkveg)
        Me.GroupBox2.Controls.Add(Me.chkpep)
        Me.GroupBox2.Controls.Add(Me.chkcheese)
        Me.GroupBox2.Location = New System.Drawing.Point(51, 287)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(225, 200)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Toppings"
        '
        'chksausage
        '
        Me.chksausage.AutoSize = True
        Me.chksausage.Location = New System.Drawing.Point(123, 44)
        Me.chksausage.Name = "chksausage"
        Me.chksausage.Size = New System.Drawing.Size(68, 17)
        Me.chksausage.TabIndex = 5
        Me.chksausage.Text = "Sausage"
        Me.chksausage.UseVisualStyleBackColor = True
        '
        'chkpine
        '
        Me.chkpine.AutoSize = True
        Me.chkpine.Location = New System.Drawing.Point(123, 89)
        Me.chkpine.Name = "chkpine"
        Me.chkpine.Size = New System.Drawing.Size(73, 17)
        Me.chkpine.TabIndex = 4
        Me.chkpine.Text = "Pineapple"
        Me.chkpine.UseVisualStyleBackColor = True
        '
        'chkveg
        '
        Me.chkveg.AutoSize = True
        Me.chkveg.Location = New System.Drawing.Point(12, 129)
        Me.chkveg.Name = "chkveg"
        Me.chkveg.Size = New System.Drawing.Size(68, 17)
        Me.chkveg.TabIndex = 3
        Me.chkveg.Text = "Vegtable"
        Me.chkveg.UseVisualStyleBackColor = True
        '
        'chkpep
        '
        Me.chkpep.AutoSize = True
        Me.chkpep.Location = New System.Drawing.Point(12, 89)
        Me.chkpep.Name = "chkpep"
        Me.chkpep.Size = New System.Drawing.Size(68, 17)
        Me.chkpep.TabIndex = 2
        Me.chkpep.Text = "Peporoni"
        Me.chkpep.UseVisualStyleBackColor = True
        '
        'chkcheese
        '
        Me.chkcheese.AutoSize = True
        Me.chkcheese.Location = New System.Drawing.Point(12, 44)
        Me.chkcheese.Name = "chkcheese"
        Me.chkcheese.Size = New System.Drawing.Size(62, 17)
        Me.chkcheese.TabIndex = 1
        Me.chkcheese.Text = "Cheese"
        Me.chkcheese.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(194, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Breadsticks"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(406, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(47, 13)
        Me.Label3.TabIndex = 11
        Me.Label3.Text = "# Pizzas"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkCoke)
        Me.GroupBox3.Controls.Add(Me.chksprite)
        Me.GroupBox3.Controls.Add(Me.chkBirch)
        Me.GroupBox3.Location = New System.Drawing.Point(51, 492)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(225, 200)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Soda"
        '
        'chkCoke
        '
        Me.chkCoke.AutoSize = True
        Me.chkCoke.Location = New System.Drawing.Point(12, 58)
        Me.chkCoke.Name = "chkCoke"
        Me.chkCoke.Size = New System.Drawing.Size(51, 17)
        Me.chkCoke.TabIndex = 8
        Me.chkCoke.Text = "Coke"
        Me.chkCoke.UseVisualStyleBackColor = True
        '
        'chksprite
        '
        Me.chksprite.AutoSize = True
        Me.chksprite.Location = New System.Drawing.Point(12, 97)
        Me.chksprite.Name = "chksprite"
        Me.chksprite.Size = New System.Drawing.Size(53, 17)
        Me.chksprite.TabIndex = 6
        Me.chksprite.Text = "Sprite"
        Me.chksprite.UseVisualStyleBackColor = True
        '
        'chkBirch
        '
        Me.chkBirch.AutoSize = True
        Me.chkBirch.Location = New System.Drawing.Point(12, 131)
        Me.chkBirch.Name = "chkBirch"
        Me.chkBirch.Size = New System.Drawing.Size(75, 17)
        Me.chkBirch.TabIndex = 7
        Me.chkBirch.Text = "Birch Beer"
        Me.chkBirch.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.radNo)
        Me.GroupBox4.Controls.Add(Me.radYes)
        Me.GroupBox4.Location = New System.Drawing.Point(313, 89)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(225, 200)
        Me.GroupBox4.TabIndex = 10
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Delivery"
        '
        'radNo
        '
        Me.radNo.AutoSize = True
        Me.radNo.Location = New System.Drawing.Point(16, 134)
        Me.radNo.Name = "radNo"
        Me.radNo.Size = New System.Drawing.Size(39, 17)
        Me.radNo.TabIndex = 1
        Me.radNo.TabStop = True
        Me.radNo.Text = "No"
        Me.radNo.UseVisualStyleBackColor = True
        '
        'radYes
        '
        Me.radYes.AutoSize = True
        Me.radYes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.radYes.Location = New System.Drawing.Point(16, 35)
        Me.radYes.Name = "radYes"
        Me.radYes.Size = New System.Drawing.Size(43, 17)
        Me.radYes.TabIndex = 0
        Me.radYes.TabStop = True
        Me.radYes.Text = "Yes"
        Me.radYes.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(636, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(34, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Total "
        '
        'lblTot
        '
        Me.lblTot.AutoSize = True
        Me.lblTot.Location = New System.Drawing.Point(748, 164)
        Me.lblTot.Name = "lblTot"
        Me.lblTot.Size = New System.Drawing.Size(34, 13)
        Me.lblTot.TabIndex = 13
        Me.lblTot.Text = "$0.00"
        '
        'lblsubtot
        '
        Me.lblsubtot.AutoSize = True
        Me.lblsubtot.Location = New System.Drawing.Point(748, 124)
        Me.lblsubtot.Name = "lblsubtot"
        Me.lblsubtot.Size = New System.Drawing.Size(34, 13)
        Me.lblsubtot.TabIndex = 14
        Me.lblsubtot.Text = "$0.00"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(636, 124)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(47, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "subtotal "
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(920, 704)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblsubtot)
        Me.Controls.Add(Me.lblTot)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnComp)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.BtnClr)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cbonum)
        Me.Controls.Add(Me.cbobread)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.lstOutput)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstOutput As ListBox
    Friend WithEvents txtname As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents cbobread As ComboBox
    Friend WithEvents cbonum As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents BtnClr As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents btnComp As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkveg As CheckBox
    Friend WithEvents chkpep As CheckBox
    Friend WithEvents chkcheese As CheckBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents radNo As RadioButton
    Friend WithEvents radYes As RadioButton
    Friend WithEvents chksausage As CheckBox
    Friend WithEvents chkpine As CheckBox
    Friend WithEvents chkCoke As CheckBox
    Friend WithEvents chksprite As CheckBox
    Friend WithEvents chkBirch As CheckBox
    Friend WithEvents radLarge As RadioButton
    Friend WithEvents radMed As RadioButton
    Friend WithEvents radSmall As RadioButton
    Friend WithEvents Label4 As Label
    Friend WithEvents lblTot As Label
    Friend WithEvents lblsubtot As Label
    Friend WithEvents Label7 As Label
End Class
