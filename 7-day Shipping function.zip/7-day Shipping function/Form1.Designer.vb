﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.txtWeight = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblsubtotal = New System.Windows.Forms.Label()
        Me.lbltotal = New System.Windows.Forms.Label()
        Me.lblfees = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.lbldiscounts = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.rad7day = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radovernight = New System.Windows.Forms.RadioButton()
        Me.rad3day = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chksignature = New System.Windows.Forms.CheckBox()
        Me.chkinsurance = New System.Windows.Forms.CheckBox()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.lsttest = New System.Windows.Forms.ListBox()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(329, 362)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(108, 45)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'txtWeight
        '
        Me.txtWeight.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWeight.Location = New System.Drawing.Point(145, 184)
        Me.txtWeight.Name = "txtWeight"
        Me.txtWeight.Size = New System.Drawing.Size(107, 26)
        Me.txtWeight.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(49, 184)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Weight (oz)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(301, 289)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Subtotal"
        '
        'lblsubtotal
        '
        Me.lblsubtotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblsubtotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsubtotal.Location = New System.Drawing.Point(285, 309)
        Me.lblsubtotal.Name = "lblsubtotal"
        Me.lblsubtotal.Size = New System.Drawing.Size(115, 33)
        Me.lblsubtotal.TabIndex = 4
        '
        'lbltotal
        '
        Me.lbltotal.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lbltotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltotal.Location = New System.Drawing.Point(682, 309)
        Me.lbltotal.Name = "lbltotal"
        Me.lbltotal.Size = New System.Drawing.Size(115, 33)
        Me.lbltotal.TabIndex = 5
        '
        'lblfees
        '
        Me.lblfees.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblfees.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfees.Location = New System.Drawing.Point(417, 309)
        Me.lblfees.Name = "lblfees"
        Me.lblfees.Size = New System.Drawing.Size(115, 33)
        Me.lblfees.TabIndex = 6
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(438, 289)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 20)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Fees"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(709, 289)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 20)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Total"
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(587, 362)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(108, 45)
        Me.btnexit.TabIndex = 9
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'lbldiscounts
        '
        Me.lbldiscounts.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lbldiscounts.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldiscounts.Location = New System.Drawing.Point(552, 309)
        Me.lbldiscounts.Name = "lbldiscounts"
        Me.lbldiscounts.Size = New System.Drawing.Size(115, 33)
        Me.lbldiscounts.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(564, 289)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(80, 20)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Discounts"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!)
        Me.Label9.Location = New System.Drawing.Point(22, 9)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(230, 29)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Slow Train Truckers"
        '
        'txtname
        '
        Me.txtname.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtname.Location = New System.Drawing.Point(145, 152)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(107, 26)
        Me.txtname.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(78, 152)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 20)
        Me.Label11.TabIndex = 16
        Me.Label11.Text = "Name"
        '
        'rad7day
        '
        Me.rad7day.AutoSize = True
        Me.rad7day.Location = New System.Drawing.Point(6, 23)
        Me.rad7day.Name = "rad7day"
        Me.rad7day.Size = New System.Drawing.Size(53, 17)
        Me.rad7day.TabIndex = 17
        Me.rad7day.TabStop = True
        Me.rad7day.Text = "7 Day"
        Me.rad7day.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radovernight)
        Me.GroupBox1.Controls.Add(Me.rad3day)
        Me.GroupBox1.Controls.Add(Me.rad7day)
        Me.GroupBox1.Location = New System.Drawing.Point(305, 60)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Shipping Days"
        '
        'radovernight
        '
        Me.radovernight.AutoSize = True
        Me.radovernight.Location = New System.Drawing.Point(5, 69)
        Me.radovernight.Name = "radovernight"
        Me.radovernight.Size = New System.Drawing.Size(71, 17)
        Me.radovernight.TabIndex = 19
        Me.radovernight.TabStop = True
        Me.radovernight.Text = "Overnight"
        Me.radovernight.UseVisualStyleBackColor = True
        '
        'rad3day
        '
        Me.rad3day.AutoSize = True
        Me.rad3day.Location = New System.Drawing.Point(5, 46)
        Me.rad3day.Name = "rad3day"
        Me.rad3day.Size = New System.Drawing.Size(53, 17)
        Me.rad3day.TabIndex = 18
        Me.rad3day.TabStop = True
        Me.rad3day.Text = "3 Day"
        Me.rad3day.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chksignature)
        Me.GroupBox2.Controls.Add(Me.chkinsurance)
        Me.GroupBox2.Location = New System.Drawing.Point(300, 175)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox2.TabIndex = 19
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Extras"
        '
        'chksignature
        '
        Me.chksignature.AutoSize = True
        Me.chksignature.Location = New System.Drawing.Point(3, 60)
        Me.chksignature.Name = "chksignature"
        Me.chksignature.Size = New System.Drawing.Size(71, 17)
        Me.chksignature.TabIndex = 1
        Me.chksignature.Text = "Signature"
        Me.chksignature.UseVisualStyleBackColor = True
        '
        'chkinsurance
        '
        Me.chkinsurance.AutoSize = True
        Me.chkinsurance.Location = New System.Drawing.Point(3, 16)
        Me.chkinsurance.Name = "chkinsurance"
        Me.chkinsurance.Size = New System.Drawing.Size(73, 17)
        Me.chkinsurance.TabIndex = 0
        Me.chkinsurance.Text = "Insurance"
        Me.chkinsurance.UseVisualStyleBackColor = True
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(459, 362)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(108, 45)
        Me.btnclear.TabIndex = 20
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'lsttest
        '
        Me.lsttest.FormattingEnabled = True
        Me.lsttest.Location = New System.Drawing.Point(524, 63)
        Me.lsttest.Name = "lsttest"
        Me.lsttest.Size = New System.Drawing.Size(264, 212)
        Me.lsttest.TabIndex = 21
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lsttest)
        Me.Controls.Add(Me.btnclear)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.lbldiscounts)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblfees)
        Me.Controls.Add(Me.lbltotal)
        Me.Controls.Add(Me.lblsubtotal)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtWeight)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents txtWeight As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblsubtotal As Label
    Friend WithEvents lbltotal As Label
    Friend WithEvents lblfees As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents btnexit As Button
    Friend WithEvents lbldiscounts As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtname As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents rad7day As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents radovernight As RadioButton
    Friend WithEvents rad3day As RadioButton
    Friend WithEvents btnclear As Button
    Friend WithEvents chksignature As CheckBox
    Friend WithEvents chkinsurance As CheckBox
    Friend WithEvents lsttest As ListBox
End Class
