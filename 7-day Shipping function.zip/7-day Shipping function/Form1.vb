﻿'	Description: A program that takes in the users name, weight of package, length of days for shipping, the optional signiture, and optional insurance, 
'   and calculates the corresponding subtotal, applicable discounts, taxes and fees, and the final cost of the transaction.
'	Name Of programmer: Dane Fisher
'   Date completed: 10/31/18
'	% completed: 100%
'	Outputs desk-checked: Yes

Public Class Form1
    Dim strname As String
    Dim intounces As Integer
    Dim weighttotal As Double
    Dim dblinsurance, dblsignature As Double

    Const tax = 0.06
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim subtotal As Double
        Dim taxtotal As Double
        Dim dbldiscount As Double
        strname = namevalid(txtname.Text)
        intOunces = CInt(txtWeight.Text)

        lsttest.Items.Add("your name: " & strname)
        lsttest.Items.Add("the amount of ounces " & intOunces)


        If rad7day.Checked = True Then
            lsttest.Items.Add("7 day total" & FormatCurrency(SevenDay(intounces), 2))
            weighttotal = SevenDay(intounces)
        End If
        If rad3day.Checked = True Then
            lsttest.Items.Add("3 day total: " & FormatCurrency(threeDay(intounces), 2))
            weighttotal = threeDay(intounces)
        End If
        If radovernight.Checked = True Then
            lsttest.Items.Add("Overnight total " & FormatCurrency(overnight(intounces), 2))
            weighttotal = overnight(intounces)
        End If
        lsttest.Items.Add("insurance: " & FormatCurrency(dblinsurance, 2))
        lsttest.Items.Add("Signature: " & FormatCurrency(dblsignature, 2))
        Dim dblsubtotal As Double
        dbldiscount = lastname(strname)
        dblsubtotal = (weighttotal + dblinsurance + dblinsurance) * dbldiscount
        subtotal = (weighttotal + dblinsurance + dblinsurance) - dblsubtotal
        lsttest.Items.Add("the discount " & FormatCurrency(dblsubtotal, 2))
        lsttest.Items.Add("subtotal: " & FormatCurrency(subtotal, 2))
        taxtotal = 0.06 * subtotal
        lsttest.Items.Add("the tax on your items: " & FormatCurrency(taxtotal, 2))
        Dim total As Double

        total = subtotal + taxtotal
        lsttest.Items.Add("The total: " & FormatCurrency(total, 2))
        'add the totals to the labels

        lblsubtotal.Text = FormatCurrency(weighttotal, 2)
        lblfees.Text = FormatCurrency((dblinsurance + dblsignature), 2)
        lbldiscounts.Text = FormatCurrency(dblsubtotal, 2)
        lbltotal.Text = FormatCurrency(total, 2)


    End Sub

    Private Function SevenDay(intWeight As Integer) As Double
        'This function takes in the input weight in ounces, and returns the shipping cost
        ' for seven-day shipping option
        Dim dblCost As Double
        If intWeight <= 16 Then
            dblCost = 8
        ElseIf intWeight <= 80 Then
            If intWeight Mod 4 = 0 Then
                dblCost = 8 + ((intWeight - 16) \ 4) * 1
            Else
                dblCost = 8 + ((intWeight - 16) \ 4) * 1 + 1
            End If
        Else
            If intWeight Mod 4 = 0 Then
                dblCost = 8 + 16 + ((intWeight - 80) \ 4) * 4
            Else
                dblCost = 8 + 16 + ((intWeight - 80) \ 4) * 4 + 4
            End If

        End If
        Return dblCost
    End Function
    Private Function threeDay(intWeight As Integer) As Double
        'This function takes in the input weight in ounces, and returns the shipping cost
        ' for three-day shipping option
        Dim dblCost As Double
        If intWeight <= 16 Then
            dblCost = 16
        ElseIf intWeight <= 80 Then
            If intWeight Mod 4 = 0 Then
                dblCost = 16 + ((intWeight - 16) \ 4) * 2
            Else
                dblCost = 16 + ((intWeight - 16) \ 4) * 2 + 1
            End If
        Else
            If intWeight Mod 4 = 0 Then
                dblCost = 16 + 16 + ((intWeight - 80) \ 4) * 4
            Else
                dblCost = 16 + 16 + ((intWeight - 80) \ 4) * 4 + 4
            End If

        End If
        Return dblCost
    End Function
    Private Function overnight(intWeight As Integer) As Double
        'This function takes in the input weight in ounces, and returns the shipping cost
        ' for overnight shipping option
        Dim dblCost As Double
        If intWeight <= 16 Then
            dblCost = 20
        ElseIf intWeight <= 80 Then
            If intWeight Mod 4 = 0 Then
                dblCost = 20 + ((intWeight - 16) \ 4) * 3
                dblCost = 20 + ((intWeight - 16) \ 4) * 3 + 1
            End If
        Else
            If intWeight Mod 4 = 0 Then
                dblCost = 8 + 16 + ((intWeight - 80) \ 4) * 4
            Else
                dblCost = 8 + 16 + ((intWeight - 80) \ 4) * 4 + 4
            End If

        End If
        Return dblCost
    End Function
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        End

    End Sub
    'adding the name validation function
    Private Function namevalid(name As String) As String

        If name = "" Then
            MessageBox.Show("You must enter a name!")
        ElseIf IsNumeric(name) = True Then
            MessageBox.Show("Your name cannot be a number!")
        Else
            name = name


        End If
        Return name
    End Function



    Private Sub chkinsurance_CheckedChanged(sender As Object, e As EventArgs) Handles chkinsurance.CheckedChanged
        If chkinsurance.Checked = True Then
            dblinsurance = 0.1 * txtWeight.Text
        Else
            dblinsurance = 0
        End If
    End Sub

    Private Sub chksignature_CheckedChanged(sender As Object, e As EventArgs) Handles chksignature.CheckedChanged
        If chkinsurance.Checked = True Then
            dblsignature = 4
        Else 
            dblsignature = 0
        End If
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        lsttest.Items.Clear()
        txtname.Clear()
        txtWeight.Clear()
        rad3day.Checked = False
        rad7day.Checked = False
        radovernight.Checked = False
        chkinsurance.Checked = False
        chksignature.Checked = False
        lbldiscounts.Text = " 0 "
        lblfees.Text = " 0 "
        lblsubtotal.Text = " 0 "
        lbltotal.Text = " 0 "




    End Sub

    Private Function lastname(name As String) As Double
        Dim split As Integer
        Dim last, upper As String
        Dim value As Double

        split = name.IndexOf(" ")
        last = name.Substring(split)
        upper = last.ToUpper
        If upper = " DAO" Or upper = " FISHER" Or last = " SMITH" Then
            value = 0.2
            MessageBox.Show("You got a discount")
        Else
            value = 0

        End If
        Return value
    End Function
End Class
