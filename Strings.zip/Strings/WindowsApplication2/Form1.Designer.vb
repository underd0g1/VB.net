﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblname = New System.Windows.Forms.Label()
        Me.lblfullname = New System.Windows.Forms.Label()
        Me.lstoutput = New System.Windows.Forms.ListBox()
        Me.btncalc = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblname
        '
        Me.lblname.AutoSize = True
        Me.lblname.ImageAlign = System.Drawing.ContentAlignment.BottomRight
        Me.lblname.Location = New System.Drawing.Point(68, 30)
        Me.lblname.Name = "lblname"
        Me.lblname.Size = New System.Drawing.Size(54, 13)
        Me.lblname.TabIndex = 0
        Me.lblname.Text = "Full Name"
        '
        'lblfullname
        '
        Me.lblfullname.AutoSize = True
        Me.lblfullname.Location = New System.Drawing.Point(142, 30)
        Me.lblfullname.Name = "lblfullname"
        Me.lblfullname.Size = New System.Drawing.Size(48, 13)
        Me.lblfullname.TabIndex = 1
        Me.lblfullname.Text = "Click Me"
        '
        'lstoutput
        '
        Me.lstoutput.FormattingEnabled = True
        Me.lstoutput.Location = New System.Drawing.Point(258, 30)
        Me.lstoutput.Name = "lstoutput"
        Me.lstoutput.Size = New System.Drawing.Size(200, 199)
        Me.lstoutput.TabIndex = 2
        '
        'btncalc
        '
        Me.btncalc.Location = New System.Drawing.Point(101, 131)
        Me.btncalc.Name = "btncalc"
        Me.btncalc.Size = New System.Drawing.Size(75, 23)
        Me.btncalc.TabIndex = 3
        Me.btncalc.Text = "Calculate"
        Me.btncalc.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(529, 440)
        Me.Controls.Add(Me.btncalc)
        Me.Controls.Add(Me.lstoutput)
        Me.Controls.Add(Me.lblfullname)
        Me.Controls.Add(Me.lblname)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblname As Label
    Friend WithEvents lblfullname As Label
    Friend WithEvents lstoutput As ListBox
    Friend WithEvents btncalc As Button
End Class
