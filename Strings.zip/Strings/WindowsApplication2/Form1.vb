﻿Public Class Form1
    Dim strname As String
    Private Sub lblfullname_Click(sender As Object, e As EventArgs) Handles lblfullname.Click

        strname = InputBox("enter your full name. ")
        lblfullname.Text = strname
    End Sub

    Private Sub btncalc_Click(sender As Object, e As EventArgs) Handles btncalc.Click
        Dim split, length As Integer
        length = strname.Length
        split = strname.IndexOf(" ")
        lstoutput.Items.Add("FullName: " & strname)
        lstoutput.Items.Add("First Name: " & strname.Substring(0, split))
        lstoutput.Items.Add("LastName: " & strname.Substring(split))
        lstoutput.Items.Add("UpperCase: " & strname.ToUpper)

    End Sub
End Class
