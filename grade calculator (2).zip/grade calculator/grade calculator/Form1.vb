﻿'Grade Calculator programm
'This programm will take in a student name and four exam grades, and then calculate the average of 4 grades and assign appropriate letter grade. 
'Programmer: Dane Fisher
'Date Completed: 10/29/18
'% Completed: 100%
'Desk checked: Yes



Public Class Form1
    'Declare the global or class level variables 
    Dim strname As String
    Dim ex1, ex2, ex3, ex4 As Integer
    Dim final As Double


    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        'form the delete button sub proceedure
        Dim intindex As Integer

        intindex = lstname.SelectedIndex

        If intindex = -1 Then
            MsgBox("you need to choose a student")
            End

        End If

        lstname.Items.RemoveAt(intindex)
        lstex1.Items.RemoveAt(intindex)
        lstex2.Items.RemoveAt(intindex)
        lstex3.Items.RemoveAt(intindex)
        lstex4.Items.RemoveAt(intindex)
        lsttot.Items.RemoveAt(intindex)
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        'clear out all the items in the listboxes when the clear button is clicked
        lstname.Items.Clear()
        lstex1.Items.Clear()
        lstex2.Items.Clear()
        lstex3.Items.Clear()
        lstex4.Items.Clear()
        lsttot.Items.Clear()


    End Sub

    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        'end the programm when the exit button is clicked
        End

    End Sub

    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        'take in the inputs for the variables and display them in the corresponding listboxes
        strname = InputBox("Enter in the student name.")
        strname = namevalid(strname)
        lstname.Items.Add(strname)
        ex1 = InputBox("enter exam 1 grade out of 100")
        ex1 = gradevalid(ex1)
        lstex1.Items.Add(ex1 & " %")
        ex2 = InputBox("enter in exam 2 grade out of 100")
        ex2 = gradevalid(ex2)
        lstex2.Items.Add(ex2 & " %")
        ex3 = InputBox("enter in exam 3 grade out of 100")
        ex3 = gradevalid(ex3)
        lstex3.Items.Add(ex3 & " %")
        ex4 = InputBox("enter in exam 4 grade out of 100")
        ex4 = gradevalid(ex4)
        lstex4.Items.Add(ex4 & " %")

        final = (ex1 + ex2 + ex3 + ex4)
        lsttot.Items.Add(lettergrade(final))


    End Sub
    'Name Validation function 
    Private Function namevalid(name As String) As String
        If name = "" Then
            MessageBox.Show("Please type in a name! ")
            End
        ElseIf IsNumeric(name) = True Then
            MessageBox.Show("Cannot be a number!")
            End
        Else
            name = name
        End If
        Return name
    End Function
    'grade validation function
    Private Function gradevalid(grade As Integer) As Integer
        If (grade < 0) Or (grade > 100) Then
            MessageBox.Show("Invalid grade")
            End
        Else
            grade = grade
        End If
        Return grade
    End Function

    Private Function lettergrade(grade As Integer) As String
        'turn the final number grade into a letter grade from a -f
        Dim letter As String
        If grade >= 360 Then
            letter = "A"
        ElseIf grade >= 320 And grade <= 359 Then
            letter = "B"
        ElseIf grade >= 280 And grade <= 319 Then
            letter = "C"
        ElseIf grade >= 240 And grade <= 279 Then
            letter = "D"
        Else
            letter = "F"
        End If
        Return letter
    End Function
    'end of programm functions 
End Class
