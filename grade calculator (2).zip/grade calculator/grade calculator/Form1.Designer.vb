﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstname = New System.Windows.Forms.ListBox()
        Me.lstex1 = New System.Windows.Forms.ListBox()
        Me.lstex2 = New System.Windows.Forms.ListBox()
        Me.lstex3 = New System.Windows.Forms.ListBox()
        Me.lstex4 = New System.Windows.Forms.ListBox()
        Me.lsttot = New System.Windows.Forms.ListBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.btnadd = New System.Windows.Forms.ToolStripMenuItem()
        Me.btndelete = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnclear = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnexit = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstname
        '
        Me.lstname.FormattingEnabled = True
        Me.lstname.Location = New System.Drawing.Point(64, 49)
        Me.lstname.Name = "lstname"
        Me.lstname.Size = New System.Drawing.Size(249, 446)
        Me.lstname.TabIndex = 0
        '
        'lstex1
        '
        Me.lstex1.FormattingEnabled = True
        Me.lstex1.Location = New System.Drawing.Point(385, 49)
        Me.lstex1.Name = "lstex1"
        Me.lstex1.Size = New System.Drawing.Size(99, 446)
        Me.lstex1.TabIndex = 1
        '
        'lstex2
        '
        Me.lstex2.FormattingEnabled = True
        Me.lstex2.Location = New System.Drawing.Point(506, 49)
        Me.lstex2.Name = "lstex2"
        Me.lstex2.Size = New System.Drawing.Size(100, 446)
        Me.lstex2.TabIndex = 2
        '
        'lstex3
        '
        Me.lstex3.FormattingEnabled = True
        Me.lstex3.Location = New System.Drawing.Point(628, 49)
        Me.lstex3.Name = "lstex3"
        Me.lstex3.Size = New System.Drawing.Size(102, 446)
        Me.lstex3.TabIndex = 3
        '
        'lstex4
        '
        Me.lstex4.FormattingEnabled = True
        Me.lstex4.Location = New System.Drawing.Point(752, 49)
        Me.lstex4.Name = "lstex4"
        Me.lstex4.Size = New System.Drawing.Size(105, 446)
        Me.lstex4.TabIndex = 4
        '
        'lsttot
        '
        Me.lsttot.FormattingEnabled = True
        Me.lsttot.Location = New System.Drawing.Point(925, 49)
        Me.lsttot.Name = "lsttot"
        Me.lsttot.Size = New System.Drawing.Size(154, 446)
        Me.lsttot.TabIndex = 5
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnadd, Me.btndelete, Me.btnclear, Me.btnexit})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1203, 24)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'btnadd
        '
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(76, 20)
        Me.btnadd.Text = "Add Student"
        '
        'btndelete
        '
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(90, 20)
        Me.btndelete.Text = "Delete Student"
        '
        'btnclear
        '
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(44, 20)
        Me.btnclear.Text = "Clear"
        '
        'btnexit
        '
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(36, 20)
        Me.btnexit.Text = "Exit"
        '
        'Label1
        '
        Me.Label1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuItem
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(61, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Student Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(382, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Exam 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(503, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Exam 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(625, 33)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Exam 3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(749, 33)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Exam 4"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(922, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Average Grade"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1203, 550)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lsttot)
        Me.Controls.Add(Me.lstex4)
        Me.Controls.Add(Me.lstex3)
        Me.Controls.Add(Me.lstex2)
        Me.Controls.Add(Me.lstex1)
        Me.Controls.Add(Me.lstname)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstname As ListBox
    Friend WithEvents lstex1 As ListBox
    Friend WithEvents lstex2 As ListBox
    Friend WithEvents lstex3 As ListBox
    Friend WithEvents lstex4 As ListBox
    Friend WithEvents lsttot As ListBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents btnadd As ToolStripMenuItem
    Friend WithEvents btndelete As ToolStripMenuItem
    Friend WithEvents btnclear As ToolStripMenuItem
    Friend WithEvents btnexit As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class
