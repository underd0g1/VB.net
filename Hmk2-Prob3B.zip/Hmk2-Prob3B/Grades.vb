﻿'Description: reads in data from ClassGrades.txt which includes 4 exam grades, homework grade, and absences. 
'             displays students weighted average And letter grade.
'Name of Programmer: Philip Deppen, Nick Desmond, Dane Fisher, Damir Wilkins
'Date completed: 12/5/18
'% completed: 100%
'Outputs desk-checked: Yes
Public Class Grades

    'class level variables
    Dim intNumOfStudents As Integer
    Dim names() As String
    Dim exam1() As Double
    Dim exam2() As Double
    Dim exam3() As Double
    Dim exam4() As Double
    Dim homework() As Double
    Dim absences() As Double
    Dim weightedAvg() As Double
    Dim letterGrade() As String

    'this subprocedure is executed on from load.
    'retrieves data from ClassGrades.txt
    Private Sub Grades_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim students() As String 'local array to hold imported data

        'import data from text file into students array
        students = IO.File.ReadAllLines("ClassGrades.txt")
        intNumOfStudents = students.Count
        MessageBox.Show("You have imported " & intNumOfStudents - 1 & " students from the Class Grades text file")

        'temp array to store data from file during looping 
        Dim tempValue() As String

        Dim i As Integer = 0

        'Use For-next loop to loop through Students() array
        For j As Integer = 1 To intNumOfStudents - 1
            tempValue = students(j).Split(","c)

            'student names
            ReDim Preserve names(i)
            names(i) = tempValue(0)

            'exam 1 grades
            ReDim Preserve exam1(i)
            exam1(i) = CInt(tempValue(1))

            'exam 2 grades
            ReDim Preserve exam2(i)
            exam2(i) = CInt(tempValue(2))

            'exam 3 grades
            ReDim Preserve exam3(i)
            exam3(i) = CInt(tempValue(3))

            'exam 4 grades
            ReDim Preserve exam4(i)
            exam4(i) = CInt(tempValue(4))

            'homework grades
            ReDim Preserve homework(i)
            homework(i) = CInt(tempValue(5))

            'absences
            ReDim Preserve absences(i)
            absences(i) = CInt(tempValue(6))

            i = i + 1
        Next

        ' display data that was imported
        lstOutput.Items.Add("Name , Exam1 , Exam2 , Exam3 , Exam4 , Homework , Absence")
        For j As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(j) & " , " & exam1(j) & " , " & exam2(j) & " , " & exam3(j) & " , " & exam4(j) & " , " & homework(j) & " , " & absences(j))
        Next

        'fill combo box in with students
        For j As Integer = 0 To intNumOfStudents - 2
            cboStudents.Items.Add(names(j))
        Next

    End Sub

    'displays homework grades for each student
    Private Sub btnHomeworkCompute_Click(sender As Object, e As EventArgs) Handles btnHomeworkCompute.Click
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name   ,   Homework %")

        'var for class average 
        Dim dblClassAverage As Double

        For i As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(i) & "  ,  " & homework(i))
            dblClassAverage += homework(i)
        Next

        dblClassAverage = dblClassAverage / (intNumOfStudents - 1)

        lstOutput.Items.Add("Class average: " & dblClassAverage)

    End Sub

    'displays exam 1 averages for 
    Private Sub btnExam1Compute_Click(sender As Object, e As EventArgs) Handles btnExam1Compute.Click
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name  , Exam 1 % Average")

        'var for class average 
        Dim dblClassAverage As Double

        'compute average
        For i As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(i) & "  ,  " & exam1(i))
            dblClassAverage += exam1(i)
        Next

        dblClassAverage = dblClassAverage / (intNumOfStudents - 1)

        lstOutput.Items.Add("Class average: " & dblClassAverage)

    End Sub

    'displays exam 2 averages for 
    Private Sub btnExam2Compute_Click(sender As Object, e As EventArgs) Handles btnExam2Compute.Click
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name  , Exam 2 % Average")

        'var for class average 
        Dim dblClassAverage As Double

        'compute average
        For i As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(i) & "  ,  " & exam2(i))
            dblClassAverage += exam2(i)
        Next

        dblClassAverage = dblClassAverage / (intNumOfStudents - 1)

        lstOutput.Items.Add("Class average: " & dblClassAverage)
    End Sub

    'displays exam 3 averages for 
    Private Sub btnExam3Compute_Click(sender As Object, e As EventArgs) Handles btnExam3Compute.Click
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name  , Exam 3 % Average")

        'var for class average 
        Dim dblClassAverage As Double

        'compute average
        For i As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(i) & "  ,  " & exam3(i))
            dblClassAverage += exam3(i)
        Next

        dblClassAverage = dblClassAverage / (intNumOfStudents - 1)

        lstOutput.Items.Add("Class average: " & dblClassAverage)

    End Sub

    'displays exam 4 averages for 
    Private Sub btnExam4Compute_Click(sender As Object, e As EventArgs) Handles btnExam4Compute.Click
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name  , Exam 4 % Average")

        'var for class average 
        Dim dblClassAverage As Double

        'compute average
        For i As Integer = 0 To intNumOfStudents - 2
            lstOutput.Items.Add(names(i) & "  ,  " & exam4(i))
            dblClassAverage += exam4(i)
        Next

        dblClassAverage = dblClassAverage / (intNumOfStudents - 1)

        lstOutput.Items.Add("Class average: " & dblClassAverage)

    End Sub

    'displays students and their calculated averages
    Private Sub btnListStudents_Click(sender As Object, e As EventArgs) Handles btnListStudents.Click
        'Exam one is worth 15% of the final overall grade
        'Exam two Is worth 20% of the grade 
        'Exam three Is worth 25% 
        'Exam four Is 30% of the grade.
        'An additional homework Is scored from 100 And Is worth 10% of the grade
        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name, Weighted Average, Letter Grade")

        Dim tempGrade As Double = 0
        Dim tempWeightedGrade As Double = 0

        Dim dblHighestGrade As Double = 0
        Dim dblLowestGrade As Double = 100

        For i As Integer = 0 To intNumOfStudents - 2
            tempWeightedGrade = 0

            'calculate weight for exam 1
            tempGrade = exam1(i)
            tempWeightedGrade = tempWeightedGrade + (tempGrade * 0.15)

            'calculate weight for exam 2
            tempGrade = exam2(i)
            tempWeightedGrade = tempWeightedGrade + (tempGrade * 0.2)

            'calculate weight for exam 3
            tempGrade = exam3(i)
            tempWeightedGrade = tempWeightedGrade + (tempGrade * 0.25)

            'calculate weight for exam 4
            tempGrade = exam4(i)
            tempWeightedGrade = tempWeightedGrade + (tempGrade * 0.3)

            'calculate weight for homework
            tempGrade = homework(i)
            tempWeightedGrade = tempWeightedGrade + (tempGrade * 0.1)

            'subtract absences
            tempWeightedGrade = tempWeightedGrade - absences(i)

            'add weighted average to array
            ReDim Preserve weightedAvg(i)
            weightedAvg(i) = tempWeightedGrade

            'each absence is minus 1 point of the overall test average. 
            'However, the maximum number of absences tolerated for a grade is 9.  
            'If a student is absent for more than 9 days, he or she is automatically given an F regardless of the weighted average.
            If absences(i) > 9 Then
                ReDim Preserve letterGrade(i)
                letterGrade(i) = "F"
            Else
                ReDim Preserve letterGrade(i)
                letterGrade(i) = LetterGradeConvert(weightedAvg(i))
            End If


            'display students data
            lstOutput.Items.Add(names(i) & " ,        " & CStr(weightedAvg(i)) & " ,       " & letterGrade(i))

            'determine highest and lowest grade for curve
            If weightedAvg(i) > dblHighestGrade Then
                dblHighestGrade = weightedAvg(i)
            End If

            If weightedAvg(i) < dblLowestGrade Then
                dblLowestGrade = weightedAvg(i)
            End If
        Next

        'compute curve
        Dim dblCurve As Double
        dblCurve = (dblHighestGrade - dblLowestGrade) * 0.1
        lstOutput.Items.Add("Curve: " & dblCurve)
    End Sub

    'calculates letter grade
    Private Function LetterGradeConvert(dblNumericGrade As Double) As String
        Dim strLetterGrade As String

        'computes letter grade
        Select Case dblNumericGrade
            Case >= 90
                strLetterGrade = "A"
            Case >= 80
                strLetterGrade = "B"
            Case >= 70
                strLetterGrade = "C"
            Case >= 60
                strLetterGrade = "D"
            Case Else
                strLetterGrade = "F"
        End Select

        Return strLetterGrade
    End Function

    'using combox box, display selected student
    Private Sub cboStudents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboStudents.SelectedIndexChanged

        'warns user that letterGrade array has not been calculated yet
        If letterGrade Is Nothing Then
            MessageBox.Show("Must click 'List Students' before calculating individual letter grades")
            Exit Sub
        End If

        Dim intSelectedStudent As Integer
        'get index selected from combo box
        intSelectedStudent = cboStudents.SelectedIndex

        'i now contains selected index (used to reduce code below)
        Dim i = intSelectedStudent

        lstOutput.Items.Clear()
        lstOutput.Items.Add("Name , Exam1 , Exam2 , Exam3 , Exam4 , Homework , Absence, Weighted Average, Letter Grade")
        'display selected student's data
        lstOutput.Items.Add(names(i) & " , " & exam1(i) & " , " & exam2(i) & " , " & exam3(i) & " , " & exam4(i) & " , " & homework(i) & " , " & absences(i) & "  ,  " & weightedAvg(i) & "  ,  " & letterGrade(i))

    End Sub

    'calculate class gpa
    Private Sub btnComputeGpa_Click(sender As Object, e As EventArgs) Handles btnComputeGpa.Click

        'warns user that letterGrade array has not been calculated yet
        If letterGrade Is Nothing Then
            MessageBox.Show("Must click 'List Students' before calculating GPA")
            Exit Sub
        End If

        lstOutput.Items.Clear()
        lstOutput.Items.Add("Class GPA")

        Dim intTotalGpa As Double = 0
        Dim tempLetterGrade As String

        For i As Integer = 0 To intNumOfStudents - 2
            tempLetterGrade = letterGrade(i)

            Select Case tempLetterGrade
                Case = "A"
                    intTotalGpa += 4
                Case = "B"
                    intTotalGpa += 3
                Case = "C"
                    intTotalGpa += 2
                Case = "D"
                    intTotalGpa += 1
                Case Else
                    intTotalGpa += 0
            End Select
        Next

        'calculate average from intTotalGpa
        intTotalGpa = intTotalGpa / (intNumOfStudents - 2)

        lstOutput.Items.Add(intTotalGpa.ToString("0.00"))

    End Sub

End Class
