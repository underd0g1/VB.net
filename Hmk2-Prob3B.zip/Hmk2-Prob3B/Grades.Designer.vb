﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Grades
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstOutput = New System.Windows.Forms.ListBox()
        Me.btnListStudents = New System.Windows.Forms.Button()
        Me.btnExam4Compute = New System.Windows.Forms.Button()
        Me.btnExam3Compute = New System.Windows.Forms.Button()
        Me.btnExam2Compute = New System.Windows.Forms.Button()
        Me.btnExam1Compute = New System.Windows.Forms.Button()
        Me.btnHomeworkCompute = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cboStudents = New System.Windows.Forms.ComboBox()
        Me.btnComputeGpa = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstOutput
        '
        Me.lstOutput.FormattingEnabled = True
        Me.lstOutput.Location = New System.Drawing.Point(374, 134)
        Me.lstOutput.Name = "lstOutput"
        Me.lstOutput.Size = New System.Drawing.Size(466, 290)
        Me.lstOutput.TabIndex = 0
        '
        'btnListStudents
        '
        Me.btnListStudents.Location = New System.Drawing.Point(12, 44)
        Me.btnListStudents.Name = "btnListStudents"
        Me.btnListStudents.Size = New System.Drawing.Size(133, 71)
        Me.btnListStudents.TabIndex = 1
        Me.btnListStudents.Text = "List Students"
        Me.btnListStudents.UseVisualStyleBackColor = True
        '
        'btnExam4Compute
        '
        Me.btnExam4Compute.Location = New System.Drawing.Point(568, 44)
        Me.btnExam4Compute.Name = "btnExam4Compute"
        Me.btnExam4Compute.Size = New System.Drawing.Size(133, 71)
        Me.btnExam4Compute.TabIndex = 2
        Me.btnExam4Compute.Text = "Exam 4 Grades"
        Me.btnExam4Compute.UseVisualStyleBackColor = True
        '
        'btnExam3Compute
        '
        Me.btnExam3Compute.Location = New System.Drawing.Point(429, 44)
        Me.btnExam3Compute.Name = "btnExam3Compute"
        Me.btnExam3Compute.Size = New System.Drawing.Size(133, 71)
        Me.btnExam3Compute.TabIndex = 3
        Me.btnExam3Compute.Text = "Exam 3 Grades"
        Me.btnExam3Compute.UseVisualStyleBackColor = True
        '
        'btnExam2Compute
        '
        Me.btnExam2Compute.Location = New System.Drawing.Point(290, 44)
        Me.btnExam2Compute.Name = "btnExam2Compute"
        Me.btnExam2Compute.Size = New System.Drawing.Size(133, 71)
        Me.btnExam2Compute.TabIndex = 4
        Me.btnExam2Compute.Text = "Exam 2 Grades"
        Me.btnExam2Compute.UseVisualStyleBackColor = True
        '
        'btnExam1Compute
        '
        Me.btnExam1Compute.Location = New System.Drawing.Point(151, 44)
        Me.btnExam1Compute.Name = "btnExam1Compute"
        Me.btnExam1Compute.Size = New System.Drawing.Size(133, 71)
        Me.btnExam1Compute.TabIndex = 5
        Me.btnExam1Compute.Text = "Exam 1 Grades"
        Me.btnExam1Compute.UseVisualStyleBackColor = True
        '
        'btnHomeworkCompute
        '
        Me.btnHomeworkCompute.Location = New System.Drawing.Point(707, 44)
        Me.btnHomeworkCompute.Name = "btnHomeworkCompute"
        Me.btnHomeworkCompute.Size = New System.Drawing.Size(133, 71)
        Me.btnHomeworkCompute.TabIndex = 6
        Me.btnHomeworkCompute.Text = "Homework Grades"
        Me.btnHomeworkCompute.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(61, 146)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(195, 55)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Check Individual Grades"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cboStudents
        '
        Me.cboStudents.FormattingEnabled = True
        Me.cboStudents.Location = New System.Drawing.Point(76, 204)
        Me.cboStudents.Name = "cboStudents"
        Me.cboStudents.Size = New System.Drawing.Size(156, 21)
        Me.cboStudents.TabIndex = 8
        '
        'btnComputeGpa
        '
        Me.btnComputeGpa.Location = New System.Drawing.Point(90, 260)
        Me.btnComputeGpa.Name = "btnComputeGpa"
        Me.btnComputeGpa.Size = New System.Drawing.Size(133, 71)
        Me.btnComputeGpa.TabIndex = 9
        Me.btnComputeGpa.Text = "Class GPA"
        Me.btnComputeGpa.UseVisualStyleBackColor = True
        '
        'Grades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(871, 450)
        Me.Controls.Add(Me.btnComputeGpa)
        Me.Controls.Add(Me.cboStudents)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnHomeworkCompute)
        Me.Controls.Add(Me.btnExam1Compute)
        Me.Controls.Add(Me.btnExam2Compute)
        Me.Controls.Add(Me.btnExam3Compute)
        Me.Controls.Add(Me.btnExam4Compute)
        Me.Controls.Add(Me.btnListStudents)
        Me.Controls.Add(Me.lstOutput)
        Me.Name = "Grades"
        Me.Text = "Grades"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents lstOutput As ListBox
    Friend WithEvents btnListStudents As Button
    Friend WithEvents btnExam4Compute As Button
    Friend WithEvents btnExam3Compute As Button
    Friend WithEvents btnExam2Compute As Button
    Friend WithEvents btnExam1Compute As Button
    Friend WithEvents btnHomeworkCompute As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents cboStudents As ComboBox
    Friend WithEvents btnComputeGpa As Button
End Class
